# lungcancer > 2023-05-21 9:24pm
https://universe.roboflow.com/lungvision-1lbmz/lungcancer-gsyck

Provided by a Roboflow user
License: CC BY 4.0

